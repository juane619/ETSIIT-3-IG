#ifndef _TETRAEDRO_H
#define _TETRAEDRO_H

#include "objeto3d.h"

class Tetraedro : public Objeto3D {
public:
    Tetraedro(float size);
};
#endif
