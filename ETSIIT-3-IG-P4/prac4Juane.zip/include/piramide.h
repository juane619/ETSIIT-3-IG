#ifndef _PIRAMIDE_H
#define _PIRAMIDE_H

#include "objeto3d.h"

class Piramide : public Objeto3D {
public:
    Piramide(float size, float altura);
};
#endif
